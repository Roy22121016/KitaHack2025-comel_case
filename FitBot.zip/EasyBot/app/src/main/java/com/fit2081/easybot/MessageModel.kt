package com.fit2081.easybot

data class MessageModel(
    val message: String,
    val role: String
)
