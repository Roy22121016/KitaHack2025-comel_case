package com.fit2081.easybot

object Constants {
    val apiKey = "AIzaSyAv4NtGLYmEg-T1Sqd9iuiB5IBafZGsfXk"
}